package sptech.school.jogoempresa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JogoEmpresaApplicationTests {

	@Test
	void contextLoads() {
	}

}
