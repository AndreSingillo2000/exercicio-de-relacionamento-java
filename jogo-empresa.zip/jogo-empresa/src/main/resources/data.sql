-- Inserir empresas fictícias
INSERT INTO empresa (nome, cnpj, endereco, cidade, estado, telefone) VALUES
('Electronic Arts', '12345678901', '123 Main St', 'Los Angeles', 'CA', '555-123-4567'),
('Ubisoft', '98765432109', '456 Elm St', 'Montreal', 'QC', '514-789-1234'),
('Rockstar Games', '45678901234', '789 Oak St', 'New York', 'NY', '212-456-7890');

-- Inserir jogos fictícios
INSERT INTO jogo (nome, genero, ano_lancamento, preco, plataforma, empresa_id) VALUES
('FIFA 22', 'Esporte', 2021, 59.99, 'PlayStation 4', 1),
('Assassin''s Creed Valhalla', 'Aventura', 2020, 49.99, 'Xbox One', 2),
('Grand Theft Auto V', 'Ação', 2013, 29.99, 'PC', 3);

INSERT INTO empresa (nome, cnpj, endereco, cidade, estado, telefone) VALUES
('Activision', '56789012345', '321 Elm St', 'Santa Monica', 'CA', '310-678-2345'),
('Square Enix', '23456789012', '987 Oak St', 'Tokyo', 'Tokyo', '81-3-4567-8901'),
('Nintendo', '67890123456', '555 Pine St', 'Kyoto', 'Kyoto', '81-75-123-4567');

INSERT INTO jogo (nome, genero, ano_lancamento, preco, plataforma, empresa_id) VALUES
('Call of Duty: Warzone', 'Tiro', 2020, 0.00, 'PC', 4),
('Final Fantasy VII Remake', 'RPG', 2020, 49.99, 'PlayStation 4', 5),
('The Legend of Zelda: Breath of the Wild', 'Aventura', 2017, 59.99, 'Nintendo Switch', 6);
