package sptech.school.jogoempresa.dto.validator;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class JogoValidatorDto {
    @NotNull
    @Size(min = 3, max = 100)
    private String nome;

    @NotNull
    @Size(min = 3, max = 50)
    private String genero;

    @NotNull
    @Min(1900)
    private int anoLancamento;

    @NotNull
    @Positive
    private double preco;

    @NotNull
    @Size(min = 5, max = 50)
    private String plataforma;
}
