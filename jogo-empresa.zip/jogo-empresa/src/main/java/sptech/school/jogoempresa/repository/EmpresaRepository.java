package sptech.school.jogoempresa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sptech.school.jogoempresa.entity.Empresa;

public interface EmpresaRepository extends JpaRepository<Empresa, Integer> {
}
