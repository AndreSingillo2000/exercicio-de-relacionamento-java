package sptech.school.jogoempresa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sptech.school.jogoempresa.entity.Jogo;

import java.util.List;
import java.util.Optional;

public interface JogoRepository extends JpaRepository<Jogo, Integer> {

    List<Jogo> findByEmpresaNomeContainsIgnoreCase(String nome);

    Optional<Jogo> findById(Integer integer);

    List<Jogo> findByNomeContainsIgnoreCase(String nome);

    List<Jogo> findByGeneroContainsIgnoreCase(String genero);

    List<Jogo> findByAnoLancamento(int anoLancamento);

    List<Jogo> findByPlataformaContainsIgnoreCase(String plataforma);


}
