package sptech.school.jogoempresa.dto.consulta;

import lombok.Data;

@Data
public class EmpresaResumidaDto {

    private String nome;
    private String cnpj;
    private String endereco;
    private String telefone;
}
