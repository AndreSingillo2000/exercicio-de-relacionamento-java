package sptech.school.jogoempresa.dto.consulta.mapper;

import sptech.school.jogoempresa.dto.consulta.EmpresaResumidaDto;
import sptech.school.jogoempresa.dto.consulta.JogoResumidoDto;
import sptech.school.jogoempresa.dto.validator.JogoValidatorDto;
import sptech.school.jogoempresa.entity.Empresa;
import sptech.school.jogoempresa.entity.Jogo;

public class JogoMapper {
    public static JogoResumidoDto toDto(Jogo entidade){

        if (entidade ==null){
            return null;
        }

        JogoResumidoDto dto = new JogoResumidoDto();
        dto.setNome(entidade.getNome());
        dto.setGenero(entidade.getGenero());
        dto.setAnoLancamento(entidade.getAnoLancamento());
        dto.setPreco(entidade.getPreco());

        EmpresaResumidaDto empresaResumidaDto = empresaResumida(entidade.getEmpresa());
        dto.setEmpresa(empresaResumidaDto);

        return dto;
    }

    public static EmpresaResumidaDto empresaResumida(Empresa entidade){
        if (entidade == null){
            return null;
        }

        EmpresaResumidaDto empresaResumidaDto = new EmpresaResumidaDto();

        empresaResumidaDto.setNome(entidade.getNome());
        empresaResumidaDto.setEndereco(entidade.getEndereco());
        empresaResumidaDto.setTelefone(entidade.getTelefone());

        return empresaResumidaDto;

    }

    public static Jogo fromValidatorDto(JogoValidatorDto jogoValidatorDto) {
        if (jogoValidatorDto == null) {
            return null;
        }

        Jogo jogo = new Jogo();
        jogo.setNome(jogoValidatorDto.getNome());
        jogo.setGenero(jogoValidatorDto.getGenero());
        jogo.setAnoLancamento(jogoValidatorDto.getAnoLancamento());
        jogo.setPreco(jogoValidatorDto.getPreco());
        jogo.setPlataforma(jogoValidatorDto.getPlataforma());

        return jogo;
    }

}
