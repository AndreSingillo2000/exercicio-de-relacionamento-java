package sptech.school.jogoempresa.dto.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class JogoValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return JogoValidatorDto.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        JogoValidatorDto jogoValidatorDto = (JogoValidatorDto) target;

        if (jogoValidatorDto.getAnoLancamento() < 1900) {
            errors.rejectValue("anoLancamento", "ano.invalido", "Ano de lançamento inválido.");
        }

        // Validação de tamanho mínimo para o campo nome
        if (jogoValidatorDto.getNome() != null && jogoValidatorDto.getNome().length() < 3) {
            errors.rejectValue("nome", "tamanho.invalido", "O campo nome deve ter pelo menos 3 caracteres.");
        }

        // Validação de tamanho mínimo para o campo gênero
        if (jogoValidatorDto.getGenero() != null && jogoValidatorDto.getGenero().length() < 3) {
            errors.rejectValue("genero", "tamanho.invalido", "O campo gênero deve ter pelo menos 3 caracteres.");
        }

        // Validação de tamanho mínimo para o campo plataforma
        if (jogoValidatorDto.getPlataforma() != null && jogoValidatorDto.getPlataforma().length() < 5) {
            errors.rejectValue("plataforma", "tamanho.invalido", "O campo plataforma deve ter pelo menos 5 caracteres.");
        }

    }
}

