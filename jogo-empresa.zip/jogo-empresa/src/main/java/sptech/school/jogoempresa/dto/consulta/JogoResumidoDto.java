package sptech.school.jogoempresa.dto.consulta;

import lombok.Data;
import sptech.school.jogoempresa.entity.Empresa;

import java.time.LocalDateTime;

@Data
public class JogoResumidoDto {

    private String nome;
    private String genero;
    private int anoLancamento;
    private double preco;

    private EmpresaResumidaDto empresa;

}
