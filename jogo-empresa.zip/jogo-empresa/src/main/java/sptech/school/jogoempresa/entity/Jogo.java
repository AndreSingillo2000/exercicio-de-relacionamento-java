package sptech.school.jogoempresa.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
public class Jogo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    private String genero;
    private int anoLancamento;
    private double preco;
    private String plataforma;

    @ManyToOne
    private Empresa empresa;

}
