package sptech.school.jogoempresa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JogoEmpresaApplication {

	public static void main(String[] args) {
		SpringApplication.run(JogoEmpresaApplication.class, args);
	}

}
