package sptech.school.jogoempresa.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sptech.school.jogoempresa.dto.consulta.JogoResumidoDto;
import sptech.school.jogoempresa.dto.consulta.mapper.JogoMapper;
import sptech.school.jogoempresa.dto.validator.JogoValidator;
import sptech.school.jogoempresa.dto.validator.JogoValidatorDto;
import sptech.school.jogoempresa.entity.Jogo;
import sptech.school.jogoempresa.repository.JogoRepository;
import org.springframework.validation.BindingResult;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
@RequestMapping("/jogos")
public class JogoController {

    private final JogoRepository jogoRepository;

    @GetMapping("/empresas")
    public ResponseEntity<List<JogoResumidoDto>> findByEmpresaNome(@RequestParam String nome){
        List<Jogo> all = jogoRepository.findByEmpresaNomeContainsIgnoreCase(nome);

        if (all.isEmpty()){
            return ResponseEntity.noContent().build();
        }

        List<JogoResumidoDto> listaAuxiliar = new ArrayList<>();

        for (Jogo jogoDaVez : all){
            JogoResumidoDto dto = JogoMapper.toDto(jogoDaVez);
            listaAuxiliar.add(dto);
        }
        return ResponseEntity.ok(listaAuxiliar);
    }

    @GetMapping("/nome")
    public ResponseEntity<List<JogoResumidoDto>> findByJogoNome(@RequestParam String nome){
        List<Jogo> all = jogoRepository.findByNomeContainsIgnoreCase(nome);

        if (all.isEmpty()){
            return ResponseEntity.noContent().build();
        }

        List<JogoResumidoDto> listaAuxiliar = new ArrayList<>();

        for (Jogo jogoDaVez : all){
            JogoResumidoDto dto = JogoMapper.toDto(jogoDaVez);
            listaAuxiliar.add(dto);
        }
        return ResponseEntity.ok(listaAuxiliar);
    }

    @GetMapping("/{id}")
    public ResponseEntity<JogoResumidoDto> findById(@PathVariable int id) {
        Optional<Jogo> jogoOpt = this.jogoRepository.findById(id);

        if (jogoOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        JogoResumidoDto dto = JogoMapper.toDto(jogoOpt.get());

        return ResponseEntity.ok(dto);
    }

    @GetMapping("/todos")
    public ResponseEntity<List<JogoResumidoDto>> listarTodosJogos() {
        List<Jogo> jogos = jogoRepository.findAll();
        if (jogos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        List<JogoResumidoDto> listaAuxiliar = new ArrayList<>();
        for (Jogo jogo : jogos) {
            JogoResumidoDto dto = JogoMapper.toDto(jogo);
            listaAuxiliar.add(dto);
        }
        return ResponseEntity.ok(listaAuxiliar);
    }

    @GetMapping("/genero")
    public ResponseEntity<List<JogoResumidoDto>> listarGeneroJogos(@RequestParam String genero) {
        List<Jogo> jogos = jogoRepository.findByGeneroContainsIgnoreCase(genero);
        if (jogos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        List<JogoResumidoDto> listaAuxiliar = new ArrayList<>();
        for (Jogo jogo : jogos) {
            JogoResumidoDto dto = JogoMapper.toDto(jogo);
            listaAuxiliar.add(dto);
        }
        return ResponseEntity.ok(listaAuxiliar);
    }

    @GetMapping("/lancamento")
    public ResponseEntity<List<JogoResumidoDto>> listarAnoLancamentoJogos(@RequestParam int anoLancamento) {
        List<Jogo> jogos = jogoRepository.findByAnoLancamento(anoLancamento);
        if (jogos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        List<JogoResumidoDto> listaAuxiliar = new ArrayList<>();
        for (Jogo jogo : jogos) {
            JogoResumidoDto dto = JogoMapper.toDto(jogo);
            listaAuxiliar.add(dto);
        }
        return ResponseEntity.ok(listaAuxiliar);
    }

    @GetMapping("/plataforma")
    public ResponseEntity<List<JogoResumidoDto>> listarPlataformJogos(@RequestParam String plataforma) {
        List<Jogo> jogos = jogoRepository.findByPlataformaContainsIgnoreCase(plataforma);
        if (jogos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        List<JogoResumidoDto> listaAuxiliar = new ArrayList<>();
        for (Jogo jogo : jogos) {
            JogoResumidoDto dto = JogoMapper.toDto(jogo);
            listaAuxiliar.add(dto);
        }
        return ResponseEntity.ok(listaAuxiliar);
    }

    @PostMapping("/criar")
    public ResponseEntity<?> criarJogo(@RequestBody @Valid JogoValidatorDto jogoDto, BindingResult errors) {
        // Valide o jogoDto usando o validador
        JogoValidator validator = new JogoValidator();
        validator.validate(jogoDto, errors);

        // Verifique se há erros de validação
        if (errors.hasErrors()) {
            return ResponseEntity.badRequest().body(errors.getAllErrors());
        }

        // Se a validação passar, continue com a criação do jogo
        Jogo jogo = JogoMapper.fromValidatorDto(jogoDto);
        Jogo novoJogo = jogoRepository.save(jogo);
        JogoResumidoDto dto = JogoMapper.toDto(novoJogo);
        return ResponseEntity.ok(dto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizarJogo(@PathVariable int id, @RequestBody @Valid JogoValidatorDto jogoDto, BindingResult errors) {
        if (errors.hasErrors()) {
            return ResponseEntity.badRequest().body(errors.getAllErrors());
        }

        Optional<Jogo> jogoOpt = jogoRepository.findById(id);

        if (jogoOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Jogo jogo = jogoOpt.get();

        jogo.setNome(jogoDto.getNome());
        jogo.setGenero(jogoDto.getGenero());

        Jogo jogoAtualizado = jogoRepository.save(jogo);
        JogoResumidoDto dto = JogoMapper.toDto(jogoAtualizado);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> excluirJogo(@PathVariable int id) {
        Optional<Jogo> jogoOpt = jogoRepository.findById(id);

        if (jogoOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        // Realize a exclusão do jogo
        jogoRepository.delete(jogoOpt.get());

        return ResponseEntity.ok("Jogo excluído com sucesso.");
    }

}
